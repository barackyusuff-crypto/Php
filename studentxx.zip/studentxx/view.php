<?php
require "db.php";
$result = mysqli_query($conn, "SELECT * FROM users");
?>
<!DOCTYPE html>
<html><head><title>View Users</title></head><body>
<h2>All Users</h2>
<?php while ($row = mysqli_fetch_assoc($result)) { ?>
<p>ID: <?php echo (int)$row["id"]; ?></p>
<p>Name: <?php echo htmlspecialchars($row["name"]); ?></p>
<p>Email: <?php echo htmlspecialchars($row["email"]); ?></p>
<a href="edit.php?id=<?php echo (int)$row["id"]; ?>">Edit</a> |
<a href="delete.php?id=<?php echo (int)$row["id"]; ?>" onclick="return confirm('Are you sure?')">Delete</a>
<hr>
<?php } ?>
<a href="dashboard.php">Dashboard</a>
</body></html>