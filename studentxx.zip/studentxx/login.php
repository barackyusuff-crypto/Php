<?php
require "db.php";
if (isset($_POST["login"])) {
    $email = $_POST["email"];
    $password = $_POST["password"];

    $sql = "SELECT * FROM users WHERE email = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user = mysqli_fetch_assoc($result);

    if ($user && password_verify($password, $user["password"])) {
        header("Location: dashboard.php");
        exit;
    } else {
        echo "Invalid email or password";
    }
    mysqli_stmt_close($stmt);
}
?>
<!DOCTYPE html>
<html><head><title>Login</title></head><body>
<h2>User Login</h2>
<form method="POST">
<input type="email" name="email" placeholder="Email" required><br><br>
<input type="password" name="password" placeholder="Password" required><br><br>
<button type="submit" name="login">Login</button>
</form>
<a href="register.php">Register</a>
</body></html>