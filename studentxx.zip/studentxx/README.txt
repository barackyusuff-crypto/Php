STUDENTXX PROJECT

DATABASE SETUP
1. Start Apache and MySQL in XAMPP.
2. Open http://localhost/phpmyadmin
3. Create a database named cms_db.
4. Select cms_db and create a table named users.
5. Create these four columns:
   id       INT, PRIMARY KEY, AUTO_INCREMENT
   name     VARCHAR(100), NOT NULL
   email    VARCHAR(100), NOT NULL
   password VARCHAR(255), NOT NULL

You can run this SQL in phpMyAdmin:
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL
);

RUN THE PROJECT
1. Put studentxx inside XAMPP's htdocs folder.
2. Start Apache and MySQL.
3. Open http://localhost/studentxx/register.php
4. Register a user.
5. Open login.php to test login.
6. Use dashboard.php to add, view, edit, and delete users.

NOTES
- One table only: users.
- Four columns: id, name, email, password.
- Passwords use password_hash() and password_verify().
- No PHP sessions are used, so login does not persist and pages are not protected.
  This is for classroom practice, not a real website.
