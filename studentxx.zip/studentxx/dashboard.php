<!DOCTYPE html>
<html><head><title>StudentXX Dashboard</title></head><body>
<h2>StudentXX Dashboard</h2>
<p>Welcome to the user management system.</p>
<a href="add.php">Add User</a><br><br>
<a href="view.php">View Users</a><br><br>
<a href="register.php">Register</a><br><br>
<a href="login.php">Login</a>
</body></html>