<?php
require "db.php";
$id = isset($_GET["id"]) ? (int)$_GET["id"] : 0;

$stmt = mysqli_prepare($conn, "SELECT * FROM users WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$user) {
    die("User not found");
}

if (isset($_POST["update"])) {
    $name = $_POST["name"];
    $email = $_POST["email"];

    $stmt = mysqli_prepare($conn, "UPDATE users SET name = ?, email = ? WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "ssi", $name, $email, $id);

    if (mysqli_stmt_execute($stmt)) {
        header("Location: view.php");
        exit;
    } else {
        echo "Update failed";
    }
    mysqli_stmt_close($stmt);
}
?>
<!DOCTYPE html>
<html><head><title>Edit User</title></head><body>
<h2>Edit User</h2>
<form method="POST">
<input type="text" name="name" value="<?php echo htmlspecialchars($user["name"]); ?>" required><br><br>
<input type="email" name="email" value="<?php echo htmlspecialchars($user["email"]); ?>" required><br><br>
<button type="submit" name="update">Update</button>
</form>
<a href="view.php">Back to users</a>
</body></html>