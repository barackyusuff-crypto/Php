<?php
require "db.php";
if (isset($_POST["save"])) {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sss", $name, $email, $password);

    if (mysqli_stmt_execute($stmt)) {
        echo "User added successfully";
    } else {
        echo "Error adding user";
    }
    mysqli_stmt_close($stmt);
}
?>
<!DOCTYPE html>
<html><head><title>Add User</title></head><body>
<h2>Add User</h2>
<form method="POST">
<input type="text" name="name" placeholder="Name" required><br><br>
<input type="email" name="email" placeholder="Email" required><br><br>
<input type="password" name="password" placeholder="Password" required><br><br>
<button type="submit" name="save">Save</button>
</form>
<a href="dashboard.php">Dashboard</a>
</body></html>