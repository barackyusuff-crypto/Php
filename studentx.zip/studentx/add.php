<?php
require "db.php";
$message = "";

if (isset($_POST["save"])) {
    $title = trim($_POST["title"]);
    $content = trim($_POST["content"]);

    $stmt = mysqli_prepare($conn, "INSERT INTO posts (title, content) VALUES (?, ?)");
    mysqli_stmt_bind_param($stmt, "ss", $title, $content);

    if (mysqli_stmt_execute($stmt)) {
        $message = "Content added successfully.";
    } else {
        $message = "Error adding content.";
    }
    mysqli_stmt_close($stmt);
}
?>
<!DOCTYPE html>
<html>
<head><title>Add Content</title></head>
<body>
<h2>Add Content</h2>
<p><?php echo htmlspecialchars($message); ?></p>
<form method="post">
    <input type="text" name="title" placeholder="Title" required><br><br>
    <textarea name="content" placeholder="Write content" required></textarea><br><br>
    <button type="submit" name="save">Save</button>
</form>
<a href="dashboard.php">Dashboard</a>
</body>
</html>
