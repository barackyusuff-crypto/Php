STUDENTX - SIMPLE PHP CMS

1. Start Apache and MySQL in XAMPP.
2. Open phpMyAdmin: http://localhost/phpmyadmin
3. Create a database named: cms_db
4. Select cms_db, open the SQL tab, and run:

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

5. Put the studentx folder inside XAMPP's htdocs folder.
6. Open: http://localhost/studentx/register.php
7. Register an admin, then go to login.php.
8. After login, open dashboard.php to add, view, edit, and delete content.

NOTE:
This classroom version uses no PHP sessions, as requested. Therefore, login does not remain active and the other pages are not protected. Do not use this no-session version for a real website.
