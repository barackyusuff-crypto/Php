<?php
require "db.php";
$result = mysqli_query($conn, "SELECT * FROM posts ORDER BY id DESC");
?>
<!DOCTYPE html>
<html>
<head><title>View Content</title></head>
<body>
<h2>All Content</h2>
<a href="add.php">Add new content</a><br><br>
<?php while ($row = mysqli_fetch_assoc($result)) { ?>
    <h3><?php echo htmlspecialchars($row["title"]); ?></h3>
    <p><?php echo nl2br(htmlspecialchars($row["content"])); ?></p>
    <a href="edit.php?id=<?php echo (int)$row["id"]; ?>">Edit</a> |
    <a href="delete.php?id=<?php echo (int)$row["id"]; ?>" onclick="return confirm('Delete this content?')">Delete</a>
    <hr>
<?php } ?>
<a href="dashboard.php">Dashboard</a>
</body>
</html>
