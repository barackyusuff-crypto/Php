<!DOCTYPE html>
<html>
<head><title>CMS Dashboard</title></head>
<body>
<h2>CMS Dashboard</h2>
<p>Welcome to the content management system.</p>
<a href="add.php">Add content</a><br><br>
<a href="view.php">View content</a><br><br>
<a href="login.php">Login page</a>
</body>
</html>
