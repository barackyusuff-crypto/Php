<?php
require "db.php";
$message = "";

if (isset($_POST["register"])) {
    $username = trim($_POST["username"]);
    $password = $_POST["password"];

    if ($username !== "" && $password !== "") {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = mysqli_prepare($conn, "INSERT INTO users (username, password) VALUES (?, ?)");
        mysqli_stmt_bind_param($stmt, "ss", $username, $hashedPassword);

        if (mysqli_stmt_execute($stmt)) {
            $message = "Admin registered successfully. You can now log in.";
        } else {
            $message = "Registration failed. Username may already exist.";
        }
        mysqli_stmt_close($stmt);
    } else {
        $message = "Please fill in all fields.";
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Register Admin</title></head>
<body>
<h2>Register Admin</h2>
<p><?php echo htmlspecialchars($message); ?></p>
<form method="post">
    <input type="text" name="username" placeholder="Username" required><br><br>
    <input type="password" name="password" placeholder="Password" required><br><br>
    <button type="submit" name="register">Register</button>
</form>
<a href="login.php">Go to login</a>
</body>
</html>
