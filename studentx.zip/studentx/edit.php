<?php
require "db.php";
$id = isset($_GET["id"]) ? (int)$_GET["id"] : 0;
$message = "";

$stmt = mysqli_prepare($conn, "SELECT title, content FROM posts WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$post = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$post) {
    die("Content not found. <a href='view.php'>Go back</a>");
}

if (isset($_POST["update"])) {
    $title = trim($_POST["title"]);
    $content = trim($_POST["content"]);

    $stmt = mysqli_prepare($conn, "UPDATE posts SET title = ?, content = ? WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "ssi", $title, $content, $id);

    if (mysqli_stmt_execute($stmt)) {
        header("Location: view.php");
        exit;
    } else {
        $message = "Update failed.";
    }
    mysqli_stmt_close($stmt);
}
?>
<!DOCTYPE html>
<html>
<head><title>Edit Content</title></head>
<body>
<h2>Edit Content</h2>
<p><?php echo htmlspecialchars($message); ?></p>
<form method="post">
    <input type="text" name="title" value="<?php echo htmlspecialchars($post["title"]); ?>" required><br><br>
    <textarea name="content" required><?php echo htmlspecialchars($post["content"]); ?></textarea><br><br>
    <button type="submit" name="update">Update</button>
</form>
<a href="view.php">Back</a>
</body>
</html>
